﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using TyrOp.Model;

namespace TyrOp.WINDOWPAGE
{
    /// <summary>
    /// Логика взаимодействия для PersonalPage.xaml
    /// </summary>
    public partial class PersonalPage : Page
    {
        private TourOperatorDBEntities _dbContext;
        private int _clientId;

        public PersonalPage()
        {
            InitializeComponent();
            _dbContext = new TourOperatorDBEntities();

            if (SessionManager.ClientId != null)
            {
                _clientId = SessionManager.ClientId.Value;
                LoadClientData();
            }
            else
            {
                MessageBox.Show("Ошибка: пользователь не авторизован.");
            }
        }

        private void LoadClientData()
        {
            var client = _dbContext.Clients.FirstOrDefault(c => c.ClientId == _clientId);
            if (client != null)
            {
                FullNameTextBox.Text = client.FullName;
                EmailTextBox.Text = client.Email;
                PhoneTextBox.Text = client.Phone;
                LoginTextBox.Text = client.Login;
                PasswordBox.Password = client.Password;
            }
        }

        private void SaveChangesButton_Click(object sender, RoutedEventArgs e)
        {
            var client = _dbContext.Clients.FirstOrDefault(c => c.ClientId == _clientId);
            if (client != null)
            {
                client.FullName = FullNameTextBox.Text;
                client.Email = EmailTextBox.Text;
                client.Phone = PhoneTextBox.Text;
                client.Login = LoginTextBox.Text;
                client.Password = PasswordBox.Password;

                _dbContext.SaveChanges();
                MessageBox.Show("Данные успешно обновлены.");
            }
        }
    }
}