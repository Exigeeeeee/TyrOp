﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using TyrOp.Model;

namespace TyrOp.WINDOWPAGE
{
    /// <summary>
    /// Логика взаимодействия для TourWindow.xaml
    /// </summary>
    public partial class TourWindow : Window
    {
        private readonly TourOperatorDBEntities _context;
        private readonly Tours _tour;

        // Конструктор для добавления нового тура
        public TourWindow()
        {
            InitializeComponent();
            _context = TourOperatorDBEntities.GetContext();

            // Заполняем ComboBox пользователями
            ResponsiblePersonComboBox.ItemsSource = _context.Users.ToList();
            ResponsiblePersonComboBox.DisplayMemberPath = "UserName";
            ResponsiblePersonComboBox.SelectedValuePath = "UserId";

            StartDatePicker.SelectedDate = DateTime.Now;
            EndDatePicker.SelectedDate = DateTime.Now.AddDays(7);
            StatusComboBox.SelectedIndex = 0; // Устанавливаем "Active" как статус по умолчанию
        }

        // Конструктор для редактирования существующего тура
        public TourWindow(Tours tour) : this()
        {
            _tour = tour;

            // Заполняем поля данными из существующего тура
            TourNameBox.Text = _tour.TourName;
            DescriptionBox.Text = _tour.Description;
            StartDatePicker.SelectedDate = _tour.StartDate;
            EndDatePicker.SelectedDate = _tour.EndDate;
            StatusComboBox.SelectedItem = _tour.Status;
        }

        private void SaveButton_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // Проверяем выбранного пользователя
                if (ResponsiblePersonComboBox.SelectedValue == null)
                {
                    MessageBox.Show("Выберите ответственное лицо для тура.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                int responsiblePersonId = (int)ResponsiblePersonComboBox.SelectedValue;

                if (_tour == null) // Режим добавления
                {
                    var newTour = new Tours
                    {
                        TourName = TourNameBox.Text.Trim(),
                        Description = DescriptionBox.Text.Trim(),
                        StartDate = StartDatePicker.SelectedDate ?? DateTime.Now,
                        EndDate = EndDatePicker.SelectedDate ?? DateTime.Now.AddDays(7),
                        Status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString(),
                        ResponsiblePersonId = responsiblePersonId
                    };

                    _context.Tours.Add(newTour);
                }
                else // Режим редактирования
                {
                    _tour.TourName = TourNameBox.Text.Trim();
                    _tour.Description = DescriptionBox.Text.Trim();
                    _tour.StartDate = StartDatePicker.SelectedDate ?? _tour.StartDate;
                    _tour.EndDate = EndDatePicker.SelectedDate ?? _tour.EndDate;
                    _tour.Status = (StatusComboBox.SelectedItem as ComboBoxItem)?.Content.ToString();
                    _tour.ResponsiblePersonId = responsiblePersonId;
                }

                _context.SaveChanges();
                MessageBox.Show("Тур успешно сохранен!", "Успех", MessageBoxButton.OK, MessageBoxImage.Information);
                DialogResult = true;
            }
            catch (System.Data.Entity.Validation.DbEntityValidationException ex)
            {
                foreach (var validationErrors in ex.EntityValidationErrors)
                {
                    foreach (var validationError in validationErrors.ValidationErrors)
                    {
                        MessageBox.Show($"Ошибка: {validationError.PropertyName} - {validationError.ErrorMessage}",
                                        "Ошибка валидации",
                                        MessageBoxButton.OK,
                                        MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Произошла ошибка: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}


